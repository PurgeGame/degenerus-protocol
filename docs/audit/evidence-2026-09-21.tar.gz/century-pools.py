from Crypto.Hash import keccak
E=10**18
H=lambda *xs:int.from_bytes(keccak.new(digest_bits=256,data=b''.join(x.to_bytes(32,'big') for x in xs)).digest(),'big')
T=lambda s:int.from_bytes(keccak.new(digest_bits=256,data=s.encode()).digest(),'big')
w=int('0ee7fcb287531227df7efcfddb3f0151121ee9e59765e743a190d8e26ee417fd',16)
v=int('38fa87cd98ee84fb4218d60a465d05e2b96fd809df17e9aead02f6d23fc09939',16)
def pool(n,f,w):
 f-=f//100
 b=1300;r=f*100//n;b += (200-r)*2 if r<200 else -min(400,r-200)
 b+=H(w,T('degenerus.skim.bps'))%1001
 take=n*b//10000;half=min(take,max(take//4,n//10));mod=half*2+1;z=H(w,T('degenerus.skim.variance'));take+=((z%mod+H(z)%mod)//2)-half;take=min(take,n*8//10)
 dump=(1825*E//100+n//400+23*E+n//100)*40//100
 return (f+take+dump)//5
if __name__=='__main__':
 for n in [5000,4500,4000,3500,3000,2500]:print(n,pool(n*E,100*E,w),pool(n*E,100*E,v))
 for target,old in [(100*E,479014751954706392492),(100*E+200,479014751954706393503),(180*E,884327883267837705624),(300*E,1490388489328443766230),(600*E,3005540004479958917745),(1100*E,5530792529732484170270)]:
  f=old
  for i in range(50):f+=(target-pool(100*E,f,w))*500//99
  print(target,f,pool(100*E,f,w))
