import runpy,json
m=runpy.run_path('/tmp/degenerus-audit-readiness-2026-09-21/century-pools.py');H=m['H'];T=m['T'];pool=m['pool'];E=m['E']
ordinals=[1,2,3,5]+list(range(7,107,2))
def target(s):
 d,r=divmod(s,100)
 return 100 if r<30 else 101+d%4 if r<95 else 105+d%46
for w in range(1,500001,2):
 pairs=far=0
 for i in ordinals:
  z=H(w,100,0x4261665469636b6574,i);a=H(z,z);b=H(a,a);a=target(a);b=target(b)
  pairs+=1+(a!=b);far+=(a>=106)+(b>=106)
 if pairs<104 or far<13:continue
 # Preserve the full 107 distinct-winner cohort, including disjoint source buckets.
 z=H(w,T('degenerus.baf.winners'));buckets=set();farlevels=set()
 for salt in range(1,54):
  z=H(z,salt)
  if salt==1:continue
  if salt<=3:farlevels.add(105+z%95);continue
  r=salt-4;t=100 if r<4 else 101+z%3 if r<12 else 99-z%99;buckets.add((t,(z>>24)&255))
 if len(farlevels)!=2 or len(buckets)!=50:continue
 for n in [5000,4500,4000,3500,3000,2500]:
  p=pool(n*E,100*E,w)
  if 110*E<p<165*E:
   print(json.dumps({'word':w,'pairs':pairs,'far':far,'next_eth':n,'baf_pool':p}),flush=True);raise SystemExit
raise RuntimeError('no pressure fixture')
