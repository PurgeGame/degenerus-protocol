from Crypto.Hash import keccak
import json
from pathlib import Path

def h(*xs):
 return int.from_bytes(keccak.new(digest_bits=256,data=b''.join(x.to_bytes(32,'big') for x in xs)).digest(),'big')
def tag(s):return int.from_bytes(keccak.new(digest_bits=256,data=s.encode()).digest(),'big')
boardtag=tag('degenerus.jackpot.trait-board');herotag=tag('degenerus.jackpot.hero-symbol');bonus=tag('BONUS_TRAITS')
mask=sum(0x38<<(6*q) for q in range(4))
def board(w):return [64*q+((h(w,boardtag)>>(6*q))&63) for q in range(4)]
def length_for(w,q,t):
 root=h(h(w,111),q);seeds=[h(root,t,239+q,i) for i in (0,8,16,24)]
 factor=seeds[0]//8+1
 for k in range(64,4097):
  if factor%k:continue
  n=k*8-7;indices=[]
  for seed in seeds:
   start=seed%(k*8)
   for used in range(8):
    ix=(start&~7)|((start+used)&7)
    indices.append(h(seed,used)%n if ix>=n else ix)
  if len(set(indices))==32 and len({i//8 for i in indices})==11:return n
 return None
for w in range(1,100000000,2):
 if h(w,boardtag)&mask!=mask:continue
 if h(w,herotag,399)%544<496:continue
 bw=h(w,bonus)
 if h(bw,herotag,399)%511<465:continue
 mt=board(w);mt[3]=(mt[3]&~7)|7
 bt=board(bw);bt[3]=(bt[3]&~7)|6
 lens=[length_for(w,q,t) for q,t in enumerate(bt)]
 if all(lens):
  result={'word':w,'main':mt,'bonus':bt,'lengths':lens}
  Path('/tmp/degenerus-audit-readiness-2026-09-21/early-bird-shape.json').write_text(json.dumps(result,indent=2)+'\n');print(result,flush=True);break
else:raise RuntimeError('no shape found')
