import json,collections
from pathlib import Path
base=Path('/tmp/degenerus-audit-readiness-2026-09-21')
f=(base/'slither-final.json').open();buf=''
while '"detectors": [' not in buf:buf+=f.read(65536)
buf=buf.split('"detectors": [',1)[1];dec=json.JSONDecoder();rows=[]
while True:
 buf=buf.lstrip(' \r\n\t,')
 if buf.startswith(']'):break
 try:obj,end=dec.raw_decode(buf)
 except json.JSONDecodeError:
  chunk=f.read(1048576)
  if not chunk:raise
  buf+=chunk;continue
 buf=buf[end:]
 rows.append({k:obj[k] for k in ['id','check','impact','confidence','description']})
counts=collections.Counter((r['impact'],r['check']) for r in rows)
result={'detectors':len(rows),'classes':[{'impact':k[0],'check':k[1],'count':n}for k,n in sorted(counts.items())],'results':rows}
(base/'slither-compact.json').write_text(json.dumps(result,indent=2)+'\n')
for k,n in sorted(counts.items()):
 if k[0]=='High':print(k,n)
for r in rows:
 if r['impact']=='High' and r['check'] in ['weak-prng','incorrect-shift','incorrect-exp','arbitrary-send-eth']:
  print(r['check'],r['description'][:900])
