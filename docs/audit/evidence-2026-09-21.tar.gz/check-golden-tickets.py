from Crypto.Hash import keccak
import re
from pathlib import Path
K=lambda b:int.from_bytes(keccak.new(digest_bits=256,data=b).digest(),'big')
W=lambda x:x.to_bytes(32,'big')
H=lambda *xs:K(b''.join(W(x) for x in xs))
owner=int('3321cB001DbF10874b0459bef62a1F1d9478D044',16)
word1=K(b'golden_word_1')|1
word3=K(W(64)+W(3)+W(11)+b'golden_word'.ljust(32,b'\0'))|1
# ABI dynamic string has 11 bytes, corrected by its actual literal length below.
word3=K(W(64)+W(3)+W(len(b'golden_word'))+b'golden_word'.ljust(32,b'\0'))|1
sizes=[9016*10**12]*6+[45080*10**12]*3+[225400*10**12]*2+[901600*10**12]
def calc(word):
 rows=[]
 for nonce,amount in enumerate(sizes,1):
  z=H(word,owner,0x426f784f70656e,nonce);roll=(z>>40&65535)%20
  lvl=1+(5+(z>>24&65535)%46 if (z&65535)%100<20 else (z>>16&255)%5)
  if roll>=8:continue
  r=(z>>96&0xffffff)%10000
  for low,hi,a,b in [(0,100,40000,65000),(100,500,20000,35000),(500,2500,10000,16000),(2500,7000,5923,9923),(7000,10000,3600,7200)]:
   if low<=r<hi:v=a+(r-low)*(b-a)//(hi-low-1);break
  price=10**16 if lvl<5 else 2*10**16 if lvl<10 else 4*10**16 if lvl<30 else 8*10**16
  budget=(amount-amount//10)*19678//10000
  budget=budget*(15000 if lvl>=6 else 8750)//10000
  tickets=(budget*v//10000)*100//price
  up=tickets%100!=0 and ((z>>224)&0xffffffff)%100<tickets%100
  rows.append((amount,lvl,tickets,up))
 return rows
expected1=[(9016*10**12,3,130,False),(9016*10**12,3,109,False),(9016*10**12,4,113,False),(45080*10**12,1,421,True),(225400*10**12,4,4671,True)]
expected3=[(9016*10**12,3,205,False),(9016*10**12,5,84,False),(225400*10**12,5,653,False),(901600*10**12,22,5356,True)]
assert calc(word1)==expected1,(calc(word1),expected1)
assert calc(word3)==expected3,(calc(word3),expected3)
print('Independent Python Keccak/ABI/ticket arithmetic: both golden vectors match all 9 ticket outcomes.')
