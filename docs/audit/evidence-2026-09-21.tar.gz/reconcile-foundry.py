from pathlib import Path
import re,json,collections
base=Path('/tmp/degenerus-audit-readiness-2026-09-21')
initial=[base/'foundry-final'/f'{x}.log' for x in ['integration-gas','repro-symbolic','fuzz-1','fuzz-2','fuzz-3','fuzz-4','invariants']]
reruns=[base/x/'focused.log' for x in ['fixes-first','fixes-second','fixes-third','century-final','final-decimator']]
def parse(p):
 rows=[];suite=None
 for line in p.read_text().splitlines():
  if line == "Failing tests:": break
  m=re.match(r'Ran \d+ tests? for (.+?):([^:]+)$',line)
  if m:suite=m[1]+':'+m[2]
  m=re.match(r'^\[(PASS|FAIL|SKIP).*?\] ((?:test|invariant|setUp)[\w]+\([^)]*\)|setUp\(\))',line)
  if m and suite:rows.append({'id':suite+':'+m[2],'status':m[1],'log':str(p.relative_to(base))})
 return rows
baseline=[x for p in initial for x in parse(p)]; latest={r['id']:r for r in baseline}
for p in reruns:
 for row in parse(p):
  latest[row['id']]=row
  if row['status']=='PASS':latest.pop(row['id'].rsplit(':',1)[0]+':setUp()',None)
failed_initial={r['id'] for r in baseline if r['status']=='FAIL'}
result={'baseline_executions':dict(collections.Counter(r['status'] for r in baseline)), 'current_unique_tests':dict(collections.Counter(r['status'] for r in latest.values())), 'initial_failures_resolved':len([x for x in failed_initial if x not in latest or latest[x]['status']=='PASS']), 'unresolved':[r for r in latest.values() if r['status']=='FAIL'], 'tests':list(latest.values())}
(base/'foundry-reconciliation.json').write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps({k:v for k,v in result.items() if k!='tests'},indent=2))
