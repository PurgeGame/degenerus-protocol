from Crypto.Hash import keccak

def h(*xs):return int.from_bytes(keccak.new(digest_bits=256,data=b''.join(x.to_bytes(32,'big') for x in xs)).digest(),'big')
def path(s):return ((s>>40)&65535)%20
def traits(s):
 out=[]
 for q in range(4):
  lane=s>>(64*q);color=(((lane&0xffffffff)*15)>>32)//2;sym=(lane>>32)&7
  out.append((color,sym))
 return out
for w in range(1,100000000):
 a=h(w,0xbeef,0x426f784f70656e,1)
 if path(a) not in (8,9,10):continue
 b=h(w,0xbeef,0x426f784f70656e,2)
 if path(b)!=19:continue
 c=h(w,0xbeef,0x426f784f70656e,3)
 if path(c) not in (8,9,10):continue
 spin=h(b,0x4574685370696e)
 child=h(h(spin,0x5265636972),0xbeef)
 if path(child) not in (8,9,10):continue
 p=traits(spin);r=traits(h(spin,1));score=sum((2 if q==(spin&3) else 1)+(pc==rc) for q,((pc,ps),(rc,rs)) in enumerate(zip(p,r)) if ps==rs)
 if score>=5:
  print(w,score,flush=True);break
else:raise RuntimeError('no word')
