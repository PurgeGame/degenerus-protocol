#include <stdio.h>
#include <stdint.h>
#include <string.h>
#include "KeccakSpongeWidth1600.h"
int main(void) {
 unsigned char input[64]={0}, output[32];
 unsigned char tag[32]={205,168,210,223,177,81,80,91,15,154,28,19,130,22,136,159,83,0,226,8,26,49,125,9,207,167,222,45,114,181,183,237};
 unsigned targets[]={15974073,13876921,7689029,7689085,7692157,7855997,9548937,14913080,15179385,15445690,15711995,15978300,16244605,16510910,16777215};
 unsigned counts[15]={0};
 unsigned left=30;
 memcpy(input+32,tag,32);
 for(uint64_t n=1;left;n++){
  for(int i=0;i<8;i++)input[31-i]=(n>>(8*i))&255;
  KeccakWidth1600_Sponge(1088,512,input,64,1,output,32);
  unsigned v=(output[29]<<16)|(output[30]<<8)|output[31];
  for(int i=0;i<15;i++) if(v==targets[i] && counts[i]<2){
   printf("%u %llu\n",v,(unsigned long long)n);fflush(stdout);counts[i]++;left--;
  }
 }
}
