# Evidence for the 2026-09-21 working-tree audit handoff

See docs/audit/snapshot.json, source-sha256.txt and verification-sha256.txt in the
repository for the delivered source/build/test inputs. The source snapshot is
based on commit 1a4d06d08aa1c5e2a15575039dd66e9c8cc1e0b3.

foundry-final contains the complete seven-group sweep during fixture repairs.
fixes-first/second/third, century-final and final-decimator contain affected-suite
reruns. Read foundry-reconciliation.json for the latest result per unique test,
including resolution of every initial failure. The decimator full-width change
followed the full sweep and was verified by final-decimator, fresh build/layout
and source checks, the full hardhat-final run and refreshed analyzers.

before-decimator-source-sha256.txt records the earlier production tree with
Foundry fixture address pins. The final pin variants are supplied separately.
Source code other than those address pins is identical in the final builds.

The Slither compact JSON retains every detector id, class, impact, confidence and
description. It omits the 849 MB raw AST/element trees. Aderyn's full report is
included. Analyzer links may refer to temporary build locations; file/line
references correspond to the sources in the snapshot. Findings need triage.

The statistical suite has two pre-disclosed failures (v36 protected-byte baseline
and STAT-03 empty-bucket expectation). Test skips and pending tests are not passes.

Gas values are emitted measurements, not the parent test's total setup gas.
Century/terminal intrinsic-inclusive values and the early-bird call-only figure
are distinguished in docs/VERIFICATION.md. No gas cap was raised.
