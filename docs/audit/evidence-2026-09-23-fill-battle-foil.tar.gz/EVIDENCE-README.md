# Supplementary evidence for the 2026-09-23 unminted-tickets, fill-battle and foil revision

Supplements the earlier 2026-09-21 and 2026-09-22 archives. The main chain ran in a detached git
worktree at 9676d23b (source identical to 5d52e4f6) with its own Foundry cache, using master_wt7.sh
(the previous archive's master script with paths updated). foundry/ is the seven-group forge snapshot
sweep under the Foundry fixture pins; gas-delta-per-test.txt compares it to the single-symbol
degenerette revision's sweep. In that sweep the invariants group reported two failures from one
suite, CrapsRealWiringConservation, whose per-run vacuity guard needs a successful vault comp grant:
a test-harness flake (the same seed passed on rerun). The handler was fixed in 41805233 (test-only;
no contract changed) and invariants-at-41805233/ is the whole invariants group re-run at that exact
revision with a fresh failure-persist directory: 133 passed, 0 failed. No invariants.snap exists in
foundry/ because the sweep's group failed, so the gas delta covers the other six groups.
gates.log, oracle.log, hardhat.log, stat.log and the two size tables were produced at 9676d23b;
the statistical suite has no failures. slither-compact.json keeps every detector row from the raw
output; slither-delta-vs-degenerette-recycle-run.txt compares it to that run. aderyn-report.md is the
full Aderyn output. source-hashes-check.log and verification-hashes-check.log are the two manifests
verified against 9676d23b. Findings need triage; skips and pending tests are not passes.
