// SPDX-License-Identifier: AGPL-3.0-only
pragma solidity 0.8.34;


/*
 * TERMS OF INTERACTION — submitting a transaction to this contract accepts them.
 *
 * THIS IS GAMBLING. Outcomes are decided by chance. You can lose everything you put in
 * simply by being unlucky. That is the software working exactly as intended. Do not
 * commit funds you are not prepared to lose entirely.
 *
 * The deployed bytecode is the entire agreement, and controls over every comment, name,
 * document and statement made about it. It has been audited but is not proven correct:
 * it may contain defects the author did not find, and by interacting with it you accept
 * that risk in full.
 *
 * Any state transition the code permits is authorised — including one that exploits a
 * defect, and including sequences the author did not intend or foresee. A bug is not a
 * breach of these terms. There is no unwritten rule behind the code for a permitted
 * transaction to violate, and no unauthorised access to this contract.
 *
 * You bear all resulting loss, whether it follows from chance or from a defect. There is
 * no refund, no rollback and no privileged party able to restore a position.
 *
 * Provided AS IS, without warranty of any kind. Full text: TERMS.md
 */

/// @title ContractAddresses
/// @notice Compile-time constant addresses for every Degenerus Protocol contract. The deploy
///         pipeline predicts addresses and patches this file before compilation.
library ContractAddresses {
    uint48 internal constant DEPLOY_DAY_BOUNDARY = 20718;
    bytes32 internal constant VRF_KEY_HASH =
        0xabababababababababababababababababababababababababababababababab;

    address internal constant ICONS_32 =
        address(0xDc64a140Aa3E981100a9becA4E685f962f0cF6C9);
    address internal constant GAME_MINT_MODULE =
        address(0x5FC8d32690cc91D4c39d9d3abcBD16989F875707);
    address internal constant GAME_ADVANCE_MODULE =
        address(0x0165878A594ca255338adfa4d48449f69242Eb8F);
    address internal constant GAME_WHALE_MODULE =
        address(0xa513E6E4b8f2a923D98304ec87F64353C4D5C853);
    address internal constant GAME_JACKPOT_MODULE =
        address(0x2279B7A0a67DB372996a5FaB50D91eAA73d2eBe6);
    address internal constant GAME_DECIMATOR_MODULE =
        address(0x8A791620dd6260079BF849Dc5567aDC3F2FdC318);
    address internal constant GAME_GAMEOVER_MODULE =
        address(0x610178dA211FEF7D417bC0e6FeD39F05609AD788);
    address internal constant GAME_LOOTBOX_MODULE =
        address(0xB7f8BC63BbcaD18155201308C8f3540b07f84F5e);
    address internal constant GAME_BOON_MODULE =
        address(0xA51c1fc2f0D1a1b8494Ed1FE312d7C3a78Ed91C0);
    address internal constant GAME_DEGENERETTE_MODULE =
        address(0x0DCd1Bf9A1b36cE34237eEaFef220932846BCD82);
    address internal constant GAME_BINGO_MODULE =
        address(0x9A676e781A523b5d0C0e43731313A708CB607508);
    address internal constant GAME_AFKING_MODULE =
        address(0x0B306BF915C4d645ff596e518fAf3F9669b97016);
    address internal constant COIN =
        address(0x959922bE3CAee4b8Cd9a407cc3ac1C251C2007B1);
    address internal constant COINFLIP =
        address(0x9A9f2CCfdE556A7E9Ff0848998Aa4a0CFD8863AE);
    address internal constant VAULT =
        address(0xa85233C63b9Ee964Add6F2cffe00Fd84eb32338f);
    address internal constant AFFILIATE =
        address(0xc6e7DF5E7b4f2A278906862b61205850344D4e7d);
    address internal constant JACKPOTS =
        address(0x59b670e9fA9D0A427751Af201D676719a970857b);
    address internal constant QUESTS =
        address(0x4ed7c70F96B99c776995fB64377f0d4aB3B0e1C1);
    address internal constant GAME =
        address(0x68B1D87F95878fE05B998F19b66F4baba5De1aed);
    address internal constant SDGNRS =
        address(0x4A679253410272dd5232B3Ff7cF5dbB88f295319);
    address internal constant DGNRS =
        address(0x7a2088a1bFc9d81c55368AE168C2C02570cB814F);
    address internal constant ADMIN =
        address(0x09635F643e140090A9A8Dcd712eD6285858ceBef);
    address internal constant DEITY_PASS =
        address(0x322813Fd9A801c5507c9de605d63CEA4f2CE6c44);
    address internal constant WWXRP =
        address(0x3Aa5ebB10DC797CAC828524e59A333d0A371443c);
    address internal constant STETH_TOKEN =
        address(0xe7f1725E7734CE288F8367e1Bb143E90bb3F0512);
    address internal constant LINK_TOKEN =
        address(0x9fE46736679d2D9a65F0992F2272dE9f3c7fa6e0);
    address internal constant GNRUS =
        address(0xc5a5C42992dECbae36851359345FE25997F5C42d);
    // Foil pack module — appended, so it shifts no prior address (AFKING_SUB_TOKEN follows).
    address internal constant GAME_FOILPACK_MODULE =
        address(0x67d269191c92Caf3cD7723F116c85e6E9bf55933);
    address internal constant AFKING_SUB_TOKEN =
        address(0xE6E340D132b5f46d1e472DebcD681B2aBc16e57E);
    // Growth-bet parimutuel — appended, so it shifts no prior address.
    address internal constant PARIMUTUEL =
        address(0xc3e53F4d16Ae77Db1c982e75a937B9f60FE63690);
    // Record-bounty trophy — appended, so it shifts no prior address.
    address internal constant RECORD_BOUNTY =
        address(0x84eA74d481Ee0A5332c457a4d796187F6Ba67fEB);
    address internal constant CREATOR =
        address(0xf39Fd6e51aad88F6F4ce6aB8827279cffFb92266);
    address internal constant VRF_COORDINATOR =
        address(0x5FbDB2315678afecb367f032d93F642f64180aa3);
    // ENS reverse registrar for contract self-naming. Optional: address(0) disables
    // it (local/test/testnet builds skip the constructor setName call). Patched per
    // network — L1 ReverseRegistrar on mainnet, L2ReverseRegistrar on Base.
    address internal constant ENS_REVERSE_REGISTRAR =
        address(0x0000000000000000000000000000000000000000);
    // Craps table — appended, so it shifts no prior address. FLIP authorizes this
    // address for mintForGame (payouts) and burnCoin (stakes), the same pair of
    // sinks every other FLIP game uses. Like every constant above it, the value
    // committed here is the Foundry deterministic-test address (DEPLOY_ORDER
    // nonce N+29), so a clean checkout tests craps unpatched; the deploy
    // pipeline overwrites it with the real prediction.
    address internal constant CRAPS =
        address(0x9E545E3C0baAB3E08CdfD552C960A1050f373042);
    // The craps dice engine — appended, so it shifts no prior address. A pure
    // contract the table reaches by STATICCALL; nothing authorizes it and it
    // authorizes nothing. Committed as its Foundry deterministic-test address
    // (nonce N+30) for the same reason as CRAPS above.
    address internal constant CRAPS_ENGINE =
        address(0xa82fF9aFd8f496c3d6ac40E2a0F282E47488CFc9);
    // The purchase-day fill draw's craps battle — appended, so it shifts no prior
    // address. Holds no storage; only GAME may call it, and it authorizes
    // nothing: it plays the drawn field and GAME credits the result. Committed
    // as its Foundry deterministic-test address (nonce N+31).
    address internal constant COIN_DRAW_BATTLE =
        address(0x1613beB3B2C4f22Ee086B2b38C1476A3cE7f78E8);
    // Chainlink LINK/ETH aggregator that values LINK donations. Optional:
    // address(0) leaves DegenerusAdmin's feed slot empty, so the reward lane
    // stays dark until the feed-swap governance path installs one. Patched per
    // network — the mainnet aggregator proxy, or MockLinkEthFeed locally.
    address internal constant LINK_ETH_FEED =
        address(0x0000000000000000000000000000000000000000);
}
