#!/bin/bash
# Evidence chain for 9676d23b, run in the detached worktree with its own Foundry cache.
W=/home/zak/Dev/PurgeGame/degenerus-c4a-evidence
S=/home/zak/.cache/purgegame-tmp/claude-1000/-home-zak-Dev-PurgeGame-degenerus-audit/a694a5c6-97aa-4630-8d4d-14fc78198c72/scratchpad
E=$S/evidence7
cd "$W" || exit 1
export FOUNDRY_CACHE_PATH=$PWD/.foundry-cache FOUNDRY_DISABLE_NIGHTLY_WARNING=1
CAP="systemd-run --user --scope -p MemoryMax=30G -p MemorySwapMax=16G --quiet"
st(){ echo "STEP $1 START $(date -u +%H:%M:%S)"; }
ex(){ echo "STEP $1 EXIT $2 $(date -u +%H:%M:%S)"; git checkout -- contracts/ContractAddresses.sol 2>/dev/null; }

st foundry-sweep; $CAP python3 $S/ev/snap_all_wt.py $E/foundry > $E/foundry-sweep.log 2>&1; ex foundry-sweep $?
st gates; make check-interfaces check-delegatecall check-raw-selectors check-rng-window check-rng-taint check-advance-calls check-unchecked check-write-owners check-pool-writes check-array-delete check-gasleft > $E/gates.log 2>&1; ex gates $?
st oracle; $CAP bash scripts/layout/storage_layout_oracle.sh > $E/oracle.log 2>&1; ex oracle $?
st sizes; $CAP bash $S/ev/hardhat_pins_sizes_wt.sh $E > $E/sizes-step.log 2>&1; ex sizes $?
st hardhat; $CAP make test-hardhat > $E/hardhat.log 2>&1; ex hardhat $?
st stat; $CAP npm run test:stat > $E/stat.log 2>&1; ex stat $?
st hhcompile; $CAP npx hardhat compile --force > $E/hardhat-compile-checked-in-pins.log 2>&1; ex hhcompile $?
st slither; rm -f $E/slither.json; $CAP slither . --filter-paths 'node_modules|mocks' --exclude naming-convention,solc-version,low-level-calls,assembly,too-many-digits,similar-names,dead-code --compile-force-framework hardhat --ignore-compile --json $E/slither.json > $E/slither.log 2>&1; ex slither $?
st compact; python3 $S/ev/compact_slither.py $E/slither.json $E/slither-compact.json > $E/slither-compact.log 2>&1; ex compact $?
st slitherdiff; python3 $S/ev/slither_diff.py $S/ev/slither-compact.json $E/slither-compact.json > $E/slither-delta-vs-degenerette-recycle-run.txt 2>&1; ex slitherdiff $?
st aderyn; $CAP aderyn . -o $E/aderyn-report.md > $E/aderyn.log 2>&1; ex aderyn $?
st gasdiff; python3 $S/ev/snapdiff.py $S/ev/foundry $E/foundry > $E/gas-delta-per-test.txt 2>&1; ex gasdiff $?
st hashes; sha256sum -c docs/audit/source-sha256.txt > $E/source-hashes-check.log 2>&1; ex hashes $?
sha256sum -c docs/audit/verification-sha256.txt > $E/verification-hashes-check.log 2>&1
cp docs/audit/source-sha256.txt docs/audit/verification-sha256.txt $E/ 2>/dev/null
{ echo '{'; echo '  "forge": "'"$(forge --version 2>/dev/null|head -1)"'",'; echo '  "slither": "'"$(slither --version 2>&1|head -1)"'",'; echo '  "aderyn": "'"$(aderyn --version 2>&1|head -1)"'",'; echo '  "solc": "0.8.34",'; echo '  "node": "'"$(node -v)"'"'; echo '}'; } > $E/tool-versions.json
echo "FINAL PIN STATUS:"; git status --short contracts/ContractAddresses.sol; echo "(blank = clean)"
echo "MASTER DONE $(date -u +%H:%M:%S)"
