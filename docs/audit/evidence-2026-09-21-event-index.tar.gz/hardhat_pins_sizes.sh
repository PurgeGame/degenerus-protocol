#!/bin/bash
# Reproduce the Hardhat fixture's pins (default hardhat signer 0, four mocks at nonces 0..3, protocol from nonce 4),
# build with Foundry, run the size gate, restore pins.
set -u; cd /home/zak/Dev/PurgeGame/degenerus-audit; E="$1"
export FOUNDRY_CACHE_PATH=$PWD/.foundry-cache FOUNDRY_DISABLE_NIGHTLY_WARNING=1
node --input-type=module -e '
import { ethers } from "ethers";
import { predictAddresses, computeDeployDayBoundary } from "./scripts/lib/predictAddresses.js";
import { patchContractAddresses } from "./scripts/lib/patchContractAddresses.js";
const deployer = "0xf39Fd6e51aad88F6F4ce6aB8827279cffFb92266";
const mock = n => ethers.getCreateAddress({ from: deployer, nonce: n });
const external = { STETH_TOKEN: mock(1), LINK_TOKEN: mock(2), VRF_COORDINATOR: mock(0),
  LINK_ETH_FEED: "0x0000000000000000000000000000000000000000", CREATOR: deployer };
const boundary = computeDeployDayBoundary(Math.floor(Date.now()/1000));
patchContractAddresses(predictAddresses(deployer, 4), external, boundary,
  "0xabababababababababababababababababababababababababababababababab");
console.log("patched hardhat-style pins; boundary", boundary);
' || { git checkout -- contracts/ContractAddresses.sol; exit 1; }
cp contracts/ContractAddresses.sol "$E/ContractAddresses-hardhat-style.sol"
forge build --skip test > "$E/build-hardhat-pins.log" 2>&1; echo "build exit $?"
node scripts/check-deployment-sizes.js > "$E/size-hardhat-pins.json"; echo "size gate exit $?"
git checkout -- contracts/ContractAddresses.sol
forge build --skip test > "$E/build-checked-in-pins.log" 2>&1; echo "rebuild clean exit $?"
node scripts/check-deployment-sizes.js > "$E/size-checked-in-pins.json"; echo "size gate clean exit $?"
git status --short contracts/ContractAddresses.sol
