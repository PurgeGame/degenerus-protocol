import json,glob,sys,os
out={}
for f in glob.glob("forge-out/*.sol/*.json"):
    c=os.path.basename(f)[:-5]
    try: d=json.load(open(f))
    except Exception: continue
    h=d.get("deployedBytecode",{}).get("object","")
    if h and h!="0x": out[c]=len(h)//2-1
json.dump(out,open(sys.argv[1],"w"),indent=1)
print(len(out),"contracts")
