# Supplementary evidence for the 2026-09-21 event-index revision (91cc40e39bb97ae1ab50e011ff54db92021033d2)

This archive supplements evidence-2026-09-21.tar.gz. The only source change since that
archive's base is `EntryOwnerRegistered.owner` becoming an indexed topic in
contracts/storage/DegenerusGameStorage.sol. See docs/audit/snapshot.json, source-sha256.txt and
verification-sha256.txt in the repository for the delivered inputs.

foundry-before/ is a complete seven-group `forge snapshot` sweep at the base revision
(ed035463, the seed-domain tree) and foundry-after/ the same sweep at this revision, both
under the Foundry fixture pins (snap_all.py). gas-delta-per-test.txt is snapdiff.py over
the two: every moved test is explained by its number of owner registrations at +95 gas
(+104 on the foil-buy path) plus sub-0.1% via-IR codegen shifts. The one invariant that
tripped its non-vacuity guard under the runner's default seed did so on both trees and
passes with seeds 0xdeadbeef and 0x1 (invariant-reruns/). sizes_before_all.json and
sizes_after_all.json list every artifact's runtime size under the fixture pins.

gates.log, oracle.log, hardhat.log, stat.log, size-checked-in-pins.json and
size-hardhat-pins.json were produced at this revision. The Hardhat-style pins were
reproduced outside the fixture (ContractAddresses-hardhat-style.sol). The statistical
suite has its two pre-disclosed failures (v36 protected-byte baseline and STAT-03).

slither-compact.json keeps every detector id, class, impact, confidence and description
from the 890 MB raw output (compact_slither.py); slither-delta-vs-2026-09-21-baseline.txt
compares it to the seed-domain compact output. slither-first-attempt-stale-json.log
records a first invocation that ran against fixture-pinned Hardhat artifacts and was
discarded. aderyn-report.md is the full Aderyn output. Findings need triage; analyzer
output is not a clean bill of health. Skips and pending tests are not passes.
