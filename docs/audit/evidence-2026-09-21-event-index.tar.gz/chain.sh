#!/bin/bash
# Mechanical evidence chain at HEAD: gates -> oracle -> clean-pin build + size gate -> hardhat -> stat -> restore pins -> slither
cd /home/zak/Dev/PurgeGame/degenerus-audit
E="$1"; export FOUNDRY_CACHE_PATH=/home/zak/Dev/PurgeGame/degenerus-audit/.foundry-cache FOUNDRY_DISABLE_NIGHTLY_WARNING=1
step(){ echo "STEP $1 START $(date -u +%H:%M:%S)"; }
done_(){ echo "STEP $1 EXIT $2 $(date -u +%H:%M:%S)"; }
step gates; make check-interfaces check-delegatecall check-raw-selectors check-rng-window check-rng-taint check-advance-calls check-unchecked check-write-owners check-pool-writes check-array-delete check-gasleft > $E/gates.log 2>&1; done_ gates $?
step oracle; bash scripts/layout/storage_layout_oracle.sh > $E/oracle.log 2>&1; done_ oracle $?
step build-clean-pins; git checkout -- contracts/ContractAddresses.sol; forge build --skip test > $E/build-clean-pins.log 2>&1; done_ build-clean-pins $?
step size-gate; node scripts/check-deployment-sizes.js > $E/size-gate.log 2>&1; done_ size-gate $?
step hardhat; make test-hardhat > $E/hardhat.log 2>&1; done_ hardhat $?
step stat; npm run test:stat > $E/stat.log 2>&1; done_ stat $?
git checkout -- contracts/ContractAddresses.sol; echo "pins restored: $(git status --short contracts/ContractAddresses.sol || true)"
step slither; slither . --filter-paths 'node_modules|mocks' --exclude naming-convention,solc-version,low-level-calls,assembly,too-many-digits,similar-names,dead-code --compile-force-framework hardhat --ignore-compile --json $E/slither.json > $E/slither.log 2>&1; done_ slither $?
step aderyn; aderyn . -o $E/aderyn-report.md > $E/aderyn.log 2>&1; done_ aderyn $?
echo CHAIN DONE
