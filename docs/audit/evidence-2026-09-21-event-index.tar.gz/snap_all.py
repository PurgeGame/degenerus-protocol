#!/usr/bin/env python3
"""Patch pins, build (skip tests) and record sizes, then forge snapshot every group with the
same skip lists as scripts/test-foundry-groups.py; restore pins at the end."""
import importlib.util, json, os, subprocess, sys, time
from pathlib import Path
ROOT = Path("/home/zak/Dev/PurgeGame/degenerus-audit"); os.chdir(ROOT)
out = Path(sys.argv[1]); out.mkdir(parents=True, exist_ok=True)
spec = importlib.util.spec_from_file_location("g", ROOT/"scripts/test-foundry-groups.py")
g = importlib.util.module_from_spec(spec); spec.loader.exec_module(g)
files, support, batches = g.groups()
env = dict(os.environ); env.setdefault("FOUNDRY_CACHE_PATH", str(ROOT/".foundry-cache")); env["FOUNDRY_DISABLE_NIGHTLY_WARNING"]="1"
pins = ROOT/"contracts/ContractAddresses.sol"; orig = pins.read_bytes()
summary = []
try:
    subprocess.run(["node","scripts/lib/patchForFoundry.js"],check=True,stdout=open(out/"patch.log","w"),stderr=subprocess.STDOUT)
    t=time.time()
    skip_all=[a for p in files for a in ("--skip",str(p))]
    r=subprocess.run(["forge","build",*skip_all],env=env,stdout=open(out/"build.log","w"),stderr=subprocess.STDOUT)
    sizes={}
    for c in ["DegenerusGame","DegenerusGameFoilPackModule","DegenerusGameWhaleModule"]:
        d=json.load(open(ROOT/f"forge-out/{c}.sol/{c}.json")); h=d["deployedBytecode"]["object"]
        sizes[c]={"deployed":len(h)//2-1 if h.startswith("0x") else len(h)//2,"init":len(d["bytecode"]["object"])//2-1}
    (out/"sizes.json").write_text(json.dumps({"build_exit":r.returncode,"build_s":round(time.time()-t),"sizes":sizes},indent=2)+"\n")
    print(json.dumps(sizes),flush=True)
    for name,keep in batches.items():
        skip=[a for p in files if p not in keep|support for a in ("--skip",str(p))]
        t=time.time()
        r=subprocess.run(["forge","snapshot","-j","16","--snap",str(out/f"{name}.snap"),*skip],env=env,stdout=open(out/f"{name}.log","w"),stderr=subprocess.STDOUT)
        row={"group":name,"exit":r.returncode,"secs":round(time.time()-t)}
        summary.append(row); (out/"summary.json").write_text(json.dumps(summary,indent=2)+"\n"); print(json.dumps(row),flush=True)
finally:
    pins.write_bytes(orig)
    print("pins restored; git status:", subprocess.run(["git","status","--short","contracts/ContractAddresses.sol"],capture_output=True,text=True).stdout.strip() or "clean", flush=True)
