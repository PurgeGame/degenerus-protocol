import re,sys,glob,collections
def load(d):
    m={}
    for f in glob.glob(d+"/*.snap"):
        for line in open(f):
            k,_,v=line.rstrip("\n").partition(" (")
            m[k]="("+v
    return m
def num(v):
    g=re.search(r"gas: (\d+)",v)
    if g: return ("fixed",int(g.group(1)))
    g=re.search(r"μ: (\d+), ~: (\d+)",v)
    if g: return ("fuzz",int(g.group(1)),int(g.group(2)))
    return ("other",v)
b=load(sys.argv[1]); a=load(sys.argv[2])
print("before entries",len(b),"after entries",len(a))
print("only-before",sorted(set(b)-set(a))[:10]); print("only-after",sorted(set(a)-set(b))[:10])
rows=[]
for k in sorted(set(a)&set(b)):
    nb,na=num(b[k]),num(a[k])
    if nb!=na: rows.append((k,nb,na))
print("changed",len(rows))
for k,nb,na in rows:
    if nb[0]=="fixed"==na[0]: print(f"{na[1]-nb[1]:+8d}  {k}  ({nb[1]} -> {na[1]})")
    elif nb[0]=="fuzz"==na[0]: print(f"fuzz μ{na[1]-nb[1]:+d} ~{na[2]-nb[2]:+d}  {k}")
    else: print("?",k,nb,na)
