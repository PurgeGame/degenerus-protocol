import json,re,sys,collections
def load(p):
    d=json.load(open(p))
    if isinstance(d,dict) and "results" in d and isinstance(d["results"],dict): return d["results"]["detectors"]
    if isinstance(d,dict) and "results" in d: return d["results"]
    return d
def key(x):
    desc=re.sub(r"#\d+(-\d+)?","#L",x["description"])
    desc=re.sub(r"\(.*?\.sol#L\)","(F#L)",desc)
    return (x["check"],x["impact"],desc.strip())
def summary(dets):
    imp=collections.Counter(x["impact"] for x in dets)
    high=collections.Counter(x["check"] for x in dets if x["impact"]=="High")
    return imp,high
a=load(sys.argv[1]); b=load(sys.argv[2])
for name,dets in (("baseline",a),("current",b)):
    imp,high=summary(dets); print(name,"total",len(dets),dict(imp)); print("  High by check:",dict(high))
ka=collections.Counter(key(x) for x in a); kb=collections.Counter(key(x) for x in b)
new=kb-ka; gone=ka-kb
print("NEW entries:",sum(new.values()),"GONE entries:",sum(gone.values()))
for k,n in list(new.items())[:40]: print(" NEW",n,k[0],k[1],k[2][:200])
for k,n in list(gone.items())[:40]: print(" GONE",n,k[0],k[1],k[2][:200])
