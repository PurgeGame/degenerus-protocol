import json,collections,sys
from pathlib import Path
src=Path(sys.argv[1]); dst=Path(sys.argv[2])
f=src.open();buf=''
while '"detectors": [' not in buf:
    c=f.read(65536)
    if not c: raise SystemExit("no detectors array")
    buf+=c
buf=buf.split('"detectors": [',1)[1];dec=json.JSONDecoder();rows=[]
while True:
    buf=buf.lstrip(' \r\n\t,')
    if buf.startswith(']'):break
    try:obj,end=dec.raw_decode(buf)
    except json.JSONDecodeError:
        chunk=f.read(1048576)
        if not chunk:raise
        buf+=chunk;continue
    buf=buf[end:]
    rows.append({k:obj[k] for k in ['id','check','impact','confidence','description']})
counts=collections.Counter((r['impact'],r['check']) for r in rows)
result={'detectors':len(rows),'classes':[{'impact':k[0],'check':k[1],'count':n}for k,n in sorted(counts.items())],'results':rows}
dst.write_text(json.dumps(result,indent=2)+'\n')
print("rows",len(rows),{i:sum(n for (im,_),n in counts.items() if im==i) for i in ['High','Medium','Low','Informational','Optimization']})
