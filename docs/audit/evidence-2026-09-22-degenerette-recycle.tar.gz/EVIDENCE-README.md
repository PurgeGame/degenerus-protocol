# Supplementary evidence for the 2026-09-22 single-symbol degenerette and century-recycle revision (ce4443c7d98611ed58c68252c50d7319ee7c299c)

Supplements the earlier 2026-09-21 and 2026-09-22 archives. Every run here was made in a detached
git worktree checked out at this exact revision with its own Foundry cache. foundry/ is the complete
seven-group forge snapshot sweep under the Foundry fixture pins; gas-delta-per-test.txt compares it to
the reveal and incinerator revision's sweep (72325bd6). gates.log, oracle.log, hardhat.log, stat.log and
the two size tables were produced at this revision; the Hardhat-style pins were reproduced outside the
fixture. The statistical suite has its two pre-disclosed failures. slither-compact.json keeps every
detector row from the raw output; slither-delta-vs-reveal-incinerator-run.txt compares it to that run.
aderyn-report.md is the full Aderyn output. source-hashes-check.log and verification-hashes-check.log
are the two manifests verified against this tree. Findings need triage; skips and pending tests are not
passes.
