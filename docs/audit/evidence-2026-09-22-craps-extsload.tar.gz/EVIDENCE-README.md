# Supplementary evidence for the 2026-09-22 craps extsload revision (6d02e4bfa25157987159eee225e7c3673a384fd1)

This archive supplements evidence-2026-09-21.tar.gz and evidence-2026-09-21-event-index.tar.gz.
The only source change since the event-index revision is `CrapsBattle.extsload(bytes32)` plus
the headroom rail in test/craps/CrapsGas.t.sol moving from 24,300 to 24,400 bytes.

Every run here was made in a detached git worktree checked out at this exact revision, with
its own Foundry cache, because the main checkout carried unrelated uncommitted work at the time.
foundry/ is the complete seven-group `forge snapshot` sweep (snap_all_wt.py) under the Foundry
fixture pins; gas-delta-per-test.txt is snapdiff.py against the event-index revision's sweep:
every moved test is explained by +22 gas per external CrapsBattle call (one more dispatcher
compare) plus sub-0.1% deploy-size effects. gates.log, oracle.log, hardhat.log, stat.log,
size-checked-in-pins.json and size-hardhat-pins.json were produced at this revision; the
Hardhat-style pins were reproduced outside the fixture (ContractAddresses-hardhat-style.sol).
The statistical suite has its two pre-disclosed failures (v36 protected-byte baseline and STAT-03).

slither-compact.json keeps every detector id, class, impact, confidence and description from the
raw output; slither-delta-vs-event-index-run.txt compares it to the event-index compact output.
aderyn-report.md is the full Aderyn output. Findings need triage; analyzer output is not a clean
bill of health. Skips and pending tests are not passes.
