# Supplementary evidence for the 2026-09-22 reveal and incinerator revision (72325bd6404565308ed0adf1c90c214dcff7d930)

Supplements the earlier 2026-09-21 and 2026-09-22 archives. Every run here was made in a detached
git worktree checked out at this exact revision with its own Foundry cache. foundry/ is the complete
seven-group forge snapshot sweep under the Foundry fixture pins; gas-delta-per-test.txt compares it to
the craps extsload revision's sweep. gates.log, oracle.log, hardhat.log, stat.log and the two size tables
were produced at this revision; the Hardhat-style pins were reproduced outside the fixture. The
statistical suite has its two pre-disclosed failures. slither-compact.json keeps every detector row from
the raw output; slither-delta-vs-event-index-run.txt compares it to the extsload run. aderyn-report.md is
the full Aderyn output. Findings need triage; skips and pending tests are not passes.
